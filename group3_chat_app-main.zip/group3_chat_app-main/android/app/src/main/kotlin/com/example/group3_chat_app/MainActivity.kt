package com.example.group3_chat_app

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
